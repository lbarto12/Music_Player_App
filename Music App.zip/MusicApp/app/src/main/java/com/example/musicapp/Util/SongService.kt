package com.example.musicapp.Util

import android.app.*
import android.content.Intent
import android.media.MediaPlayer
import android.os.*
import androidx.core.app.NotificationCompat
import com.example.musicapp.MainActivity
import com.example.musicapp.R
import kotlinx.android.synthetic.main.activity_main.*
import android.content.BroadcastReceiver
import android.content.Context
import android.graphics.Color
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity;


class SongService : Service() {

    override fun onCreate() {
        super.onCreate()
        binder = MainBinder()
        SongService.songAdapter = SongAdapter(mutableListOf())
        SongService.self = this
    }


    // BINDER
    override fun onBind(p0: Intent?): IBinder {
        return binder
    }

    inner class MainBinder : Binder() {
        fun getSongService(): SongService {
            return this@SongService
        }
    }
    // !BINDER




    // THREAD TO UPDATE TRACK

    override fun onStart(intent: Intent?, startId: Int) {
        super.onStart(intent, startId)

        Thread{
            while (running) {
                // Switch to next song

                if (MainActivity.songService.currentMediaPlayer.currentPosition == MainActivity.songService.currentMediaPlayer.duration){
                    nextSong()
                    shouldUpdate = true
                }
                Thread.sleep(1000)
            }
        }.start()
    }

    // !THREAD TO UPDATE TRACK




    // NOTIFICATION
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        updateNotification()
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val nc = NotificationChannel(
                "SongChannel1",
                "Foreground Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val m = getSystemService(NotificationManager::class.java)
            m.createNotificationChannel(nc)
        }
    }

    private fun updateNotification(){
        //val inten = Intent(this, MainActivity::class.java)

        val inten = Intent(this, MainActivity::class.java)

        val pending = PendingIntent.getActivity(this, 0, inten, 0)

        // BUTTON INTENTS
        val prevIntent = Intent(this, ActionReceiver::class.java).apply {
            action = ACTION_PREV
        }
        val nextIntent = Intent(this, ActionReceiver::class.java).apply {
            action = ACTION_NEXT
        }
        val pauseIntent = Intent(this, ActionReceiver::class.java).apply {
            action = ACTION_PAUSE
        }

        val pendingPrevIntent = PendingIntent.getBroadcast(this,
            0,
            prevIntent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )

        val pendingNextIntent = PendingIntent.getBroadcast(this,
            0,
            nextIntent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )

        val pendingPauseIntent = PendingIntent.getBroadcast(this,
            0,
            pauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT
        )


        notification = NotificationCompat.Builder(this, "SongChannel1")
            .setContentTitle(currentSongObj.name)
            .setContentText(currentSongObj.artist)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setSound(null)
            .setContentIntent(pending)
            .setShowWhen(false)
            .setWhen(0)
            .setStyle(androidx.media.app.NotificationCompat.MediaStyle())
            .addAction(R.drawable.not_prev, "PREV", pendingPrevIntent)
            .addAction(if (paused) R.drawable.not_play else R.drawable.not_pause, if (paused) "PLAY" else "PAUSE", pendingPauseIntent)
            .addAction(R.drawable.not_next, "NEXT", pendingNextIntent)
            .build()


        startForeground(1, notification)
    }

    // !NOTIFICATION



    // VARS
    private lateinit var binder: MainBinder
    private var notification: Notification? = null
    private var running: Boolean = true

    var shouldUpdate: Boolean = false
    var currentMediaPlayer: MediaPlayer = MediaPlayer()
    var currentSongObj: Song = Song("N/a", "N/a", "N/a", MediaPlayer())
    var currentSongIndex: Int = 0
    var paused: Boolean = true;

    companion object {
        lateinit var songAdapter: SongAdapter
        lateinit var self: SongService

        val ACTION_PREV = "prev"
        val ACTION_NEXT = "next"
        val ACTION_PAUSE = "pause"
    }
    // !VARS



    // MUSIC CONTROLS
    fun changeSongTo(position: Int){
        val current = songAdapter.songs[position]
        currentMediaPlayer.pause()
        currentMediaPlayer.seekTo(0)
        currentMediaPlayer = current.mediaPlayer
        currentMediaPlayer.start()
        paused = false
        currentSongObj = current

        MainActivity.getSelf().changeCurrentSongText(current.name)
        MainActivity.getSelf().playPause.setBackgroundResource(
            R.drawable.stop
        )
        updateNotification()
    }

    fun togglePlay(): Boolean {
        if (paused && !currentMediaPlayer.isPlaying) currentMediaPlayer.start()
        else currentMediaPlayer.pause()
        paused = !paused

        updateNotification()
        return paused
    }

    fun nextSong(){
        currentSongIndex++
        if (currentSongIndex > songAdapter.songs.size - 1) currentSongIndex = 0
        changeSongTo(currentSongIndex)
        updateNotification()
    }

    fun prevSong(){
        currentSongIndex--
        if (currentSongIndex < 0) currentSongIndex = songAdapter.songs.size - 1
        changeSongTo(currentSongIndex)
        updateNotification()
    }

    // !MUSIC CONTROLS




    // DESTRUCTOR
    override fun onDestroy() {
        stopForeground(true)
        stopSelf()
        running = false
        super.onDestroy()
    }
}