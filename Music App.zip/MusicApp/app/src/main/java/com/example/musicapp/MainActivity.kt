package com.example.musicapp

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.SeekBar
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.musicapp.Util.Song
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.reflect.Field
import android.os.IBinder
import com.example.musicapp.Util.SongService


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MainActivity.self = this
        val intent = Intent(this, SongService::class.java)
        applicationContext.bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        println("RE OPENED")
        if (isBound) main()
    }


    // VARS

    companion object {
        public lateinit var self: MainActivity
//        lateinit var songAdapter: SongAdapter

        lateinit var songService: SongService
        var isBound: Boolean = false
        var serviceConnection = SConnect()

        @JvmName("getSelf1")
        public fun getSelf(): MainActivity {
            return self
        }

        fun songNameBuilder(name: String): String {
            return name.replace("_", " ")
        }
    }

    // !VARS


    // MAIN -> LINK BUTTONS; SERVICE; FIELDS; ETC

    private fun main() {
        startService(Intent(this, SongService::class.java))

        if (isBound) {
            currentSong.text = songService.currentSongObj.name
            if (!songService.paused) playPause.setBackgroundResource(R.drawable.stop)
        }


        mainRecycler.adapter = SongService.songAdapter
        mainRecycler.layoutManager = LinearLayoutManager(this)


        val fields: Array<Field> = R.raw::class.java.fields
        fields.forEach {

            val filename = "android.resource://" + this.packageName + "/raw/" + it.name

            val mp = MediaPlayer.create(
                this,
                resources.getIdentifier(it.name, "raw", packageName)
            );


            val artist = "X";
            val album = "X";

            SongService.songAdapter.addSong(
                Song(
                    songNameBuilder(it.name?: "No Name"),
                    artist ?: "No Artist",
                    album ?: "No Album",
                    mp
                )
            )
        }


        currentSong.setOnClickListener {
            val intent = Intent(this, MusicControl::class.java)
            startActivity(intent)
        }

        playPause.setOnClickListener {
            if (songService.togglePlay()){
                playPause.setBackgroundResource(R.drawable.play)
            }
            else {
                playPause.setBackgroundResource(R.drawable.stop)
            }
        }


        timeStampBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p2){
                    songService.currentMediaPlayer.seekTo(p1)
                    timeStampBar.progress = p1

                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}

            override fun onStopTrackingTouch(p0: SeekBar?) {}

        })

        Thread {
            while (true){
                timeStampBar.max = songService.currentMediaPlayer.duration
                timeStampBar.progress = songService.currentMediaPlayer.currentPosition
                Thread.sleep(1000)
            }
        }.start()

    }
    // !MAIN


    // DISPLAY

    public fun changeCurrentSongText(name: String){
        currentSong.text = name
    }

    fun updatePlayPause(){
        if (songService.paused)
            playPause.setBackgroundResource(R.drawable.play)
        else
            playPause.setBackgroundResource(R.drawable.stop)
    }

    // !DISPLAY




    // SERVICE CONNECTION OBJECT

    class SConnect : ServiceConnection {

        override fun onServiceConnected(p0: ComponentName?, p1: IBinder?) {
            val b = p1 as SongService.MainBinder
            println("CONNECTED")
            songService = b.getSongService()
            isBound = true
            MainActivity.getSelf().main()
        }

        override fun onServiceDisconnected(p0: ComponentName?) {
            isBound = false
        }

    }

    // !SERVICE CONNECTION OBJECT
}
