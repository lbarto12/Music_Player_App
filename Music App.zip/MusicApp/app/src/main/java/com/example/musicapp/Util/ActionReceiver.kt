package com.example.musicapp.Util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.musicapp.MainActivity

class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {

        val action = intent.action
        if (action == SongService.ACTION_PREV) {
            SongService.self.nextSong()
        }
        else if (action == SongService.ACTION_NEXT) {
            SongService.self.prevSong()
        }
        else if (action == SongService.ACTION_PAUSE) {
            SongService.self.togglePlay()
        }
    }

}