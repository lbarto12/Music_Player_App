package com.example.musicapp

import android.media.AudioManager
import android.os.*
import android.widget.SeekBar
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.example.musicapp.Util.Song
import com.example.musicapp.Util.SongAdapter
import kotlinx.android.synthetic.main.music_controls.*
import java.lang.Exception
import kotlin.math.max

class MusicControl: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.music_controls)

        initVolumeChanger()
        initDurationBar()
        main()
    }

    // STATS FOR VIEWS / SEEKBARS

    private fun initVolumeChanger(){
        val am: AudioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val volume = am.getStreamVolume(AudioManager.STREAM_MUSIC)


        volumeBar.max = 10
        volumeBar.progress = volume

        volumeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, p1, 0)
            }
            override fun onStartTrackingTouch(p0: SeekBar?) {}
            override fun onStopTrackingTouch(p0: SeekBar?) {}
        }
        )
    }


    private var stop = false


    private fun initDurationBar(){
        durationBar.max = MainActivity.songService.currentMediaPlayer.duration
        endDuration.text = createTimeString(durationBar.max)

        durationBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                if (p2){
                    MainActivity.songService.currentMediaPlayer.seekTo(p1)
                    durationBar.progress = p1

                }
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {}

            override fun onStopTrackingTouch(p0: SeekBar?) {}

        })

        Thread {
            while (!stop){
                // Progress Bar
                durationBar.progress = MainActivity.songService.currentMediaPlayer.currentPosition

                // Time Stamp
                timeStamp.post(Runnable {
                    kotlin.run {
                        timeStamp.text = createTimeString(MainActivity.songService.currentMediaPlayer.currentPosition)
                    }
                })

                if (MainActivity.songService.shouldUpdate) {
                    updateDisplay()
                    MainActivity.songService.shouldUpdate = false
                }
                Thread.sleep(1000)
            }
        }.start()




    }

    // !STATS FOR VIEWS / SEEKBARS


    // MAIN -> LINK BUTTONS
    private fun main() {


        returnToSongs.setOnClickListener{
            finish()
        }

        // Play button stuff
        ppButton.setBackgroundResource(
            if (MainActivity.songService.paused) R.drawable.play
            else R.drawable.stop
        )

        ppButton.setOnClickListener {
            ppButton.setBackgroundResource(
                if (MainActivity.songService.togglePlay()) R.drawable.play
                else R.drawable.stop
            )

        }

        prevSong.setOnClickListener { MainActivity.songService.prevSong(); updateDisplay(); }
        nextSong.setOnClickListener { MainActivity.songService.nextSong(); updateDisplay(); }

        updateDisplay()

    }
    // !MAIN


    // DISPLAY
    private fun updateDisplay() {

        val song = MainActivity.songService.currentSongObj
        songTitle.post{songTitle.text = song.name}
        artistName.post{ artistName.text = song.artist }
        albumName.post { albumName.text = song.album }
        durationBar.post{ durationBar.max = MainActivity.songService.currentMediaPlayer.duration }
        endDuration.post{ endDuration.text = createTimeString(durationBar.max) }

        ppButton.post{
            ppButton.setBackgroundResource(
                if (MainActivity.songService.paused) R.drawable.play
                else R.drawable.stop
            )
        }

    }
    // !DISPLAY


    // UTIL
    fun createTimeString(t: Int): String {
        val minutes = t / 1000 / 60
        val seconds = t / 1000 % 60

        val leadingZero: String = if (seconds < 10) "0" else ""

        return "$minutes:$leadingZero$seconds"
    }
    // !UTIL


    override fun onDestroy() {
        super.onDestroy()
        stop = true
        MainActivity.getSelf().updatePlayPause()
    }
}