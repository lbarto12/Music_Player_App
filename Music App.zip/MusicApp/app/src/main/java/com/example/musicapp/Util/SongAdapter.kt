package com.example.musicapp.Util

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.media.MediaPlayer
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.example.musicapp.MainActivity
import com.example.musicapp.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.song_cell.view.*
import org.intellij.lang.annotations.JdkConstants


class SongAdapter(
    val songs: MutableList<Song>
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    class SongViewHolder(view: View): RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        return SongViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.song_cell,
                parent,
                false
            )
        )
    }


    fun addSong(song: Song){
        songs.add(song)
        notifyItemInserted(songs.size - 1)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val current = songs[position]

        holder.itemView.apply {
            boundingBox.text = current.name
            boundingBox.setOnClickListener {
                MainActivity.songService.changeSongTo(position)
                MainActivity.songService.currentSongIndex = position
            }
        }
    }


    override fun getItemCount(): Int {
        return songs.size
    }
}