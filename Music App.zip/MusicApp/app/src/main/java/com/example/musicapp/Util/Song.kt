package com.example.musicapp.Util

import android.media.MediaPlayer

data class Song(
    val name: String,
    val artist: String,
    val album: String,
    val mediaPlayer: MediaPlayer,
)